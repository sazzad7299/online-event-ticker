
<?php $__env->startSection('main_content'); ?>
    <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">All Category</h1>
            <a href="<?php echo e(route('addCategoryForm')); ?>"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" ><i
                    class="fas fa-plus fa-sm text-white-50"></i> Add Category</a>
                      

        </div>
        <table id="dataTable" class="table table-bordered">
            <thead>
              <tr class="text-center" style="background:rgb(35, 35, 245)">
                <th scope="col" class="text-white">#</th>
                <th scope="col" class="text-white">Title</th>
                <th scope="col" class="text-white">Parent</th>
                <th scope="col" class="text-white">Status</th>
                <th scope="col" class="text-white">Photo</th>
                <th class="text-white" scope="col">Action</th>

              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
                <tr class="text-center">
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->title); ?></td>
                    <td>
                        <?php if($category->parent_id == NULL): ?>
                          Main Category
                        <?php else: ?>
                       <?php    
                        $parent_cat= DB::table('categories')->where('id',$category->parent_id)->get();
                       ?>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($category->status=='active'): ?>
                            <span class="badge badge-success"><?php echo e($category->status); ?> </span>
                        <?php else: ?>
                        <span class="badge badge-warning"><?php echo e($category->status); ?> </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <img src="<?php echo e(asset('images/category/'.$category->photo)); ?>" alt="" width="100" height="100" style="border-radius:50%">
                    </td>
                    <td>
                        <a href="<?php echo e(route('editCategory',$category->id)); ?>"  class="btn btn-primary btn-sm mr-1 edit"><span class="fa fa-edit"></span></a>
                                          
                        <a href="<?php echo e(route('deleteCategory',$category->id)); ?>"  class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                    </td>

                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              
            </tbody>
          </table>


    </div>    


    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/category/index.blade.php ENDPATH**/ ?>