  <!-- Main Carousel Section Start -->
  <div id="main-slide" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li data-target="#main-slide" data-slide-to="<?php echo $key ?>" <?php if($key==0): ?> class="ctive" <?php endif; ?>></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    <div class="carousel-inner">
      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item <?php if($key==0): ?> active <?php endif; ?>" >
        <img class="d-block w-100" src="<?php echo e(asset('assets/img/slider/'.$slider->image)); ?>" alt="$slider->image">
        <div class="carousel-caption d-md-block">
          <p class="fadeInUp wow" data-wow-delay=".6s"><?php echo e($slider->text); ?></p>
          <h1 class="wow fadeInDown heading" data-wow-delay=".4s"><?php echo e($slider->title); ?></h1>
          <a href="#" class="fadeInLeft wow btn btn-common btn-lg" data-wow-delay=".6s">Get Ticket</a>
          <a href="#" class="fadeInRight wow btn btn-border btn-lg" data-wow-delay=".6s">Explore More</a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a class="carousel-control-prev" href="#main-slide" role="button" data-slide="prev">
      <span class="carousel-control" aria-hidden="true"><em class="lni-chevron-left"></em></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#main-slide" role="button" data-slide="next">
      <span class="carousel-control" aria-hidden="true"><em class="lni-chevron-right"></em></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  <!-- Main Carousel Section End --><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/layouts/slider.blade.php ENDPATH**/ ?>