

<?php $__env->startSection('content'); ?>
<div class="dashboard " style="background:black;padding-top:70px">
</div>
<div class="dashboard1">
    <div class="right-sidebar">
        <ul>
            <li><a href="#" class="active">Dashboard</a></li>
            <li><a href="<?php echo e(route('booking')); ?>">Booking</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
          </ul>
    </div>
    <div class="navb">
        <ul>
          <li><a href="#" class="active"><em class="lni lni-home"></em></a></li>
          <li><a href="<?php echo e(route('booking')); ?>" ><em class="lni lni-cart-full"></em></a></li>
          <li><a href="<?php echo e(route('profile')); ?>"><em class="lni lni-user"></em></a></li>
        </ul>
    </div>
    <div class="content">
        <div class="heading-count">
            <h2 class="wow fadeInDown" data-wow-delay="0.2s">Hi, <?php echo e(Auth::user()->name); ?>!</h2>
        </div>
        <div id="item" class="time-count">
            <a style="course:pointer" class="time-entry days"><span>0</span>Completed Event</a>

            <div class="time-entry"><span>00</span> On Going</div>
            <div class="time-entry"><span>00</span> Upcomming</div>
            <a href="<?php echo e(route('profile')); ?>" class="time-entry" class="btn btn-primary" ><span><em class="lni lni-user"></em></span> Profile</a>
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/home.blade.php ENDPATH**/ ?>