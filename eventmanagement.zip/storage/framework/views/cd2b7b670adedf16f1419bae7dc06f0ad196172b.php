
<?php $__env->startSection('main_content'); ?>
    <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">AlL Events</h1>
            <a href="<?php echo e(route('addHall')); ?>"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" ><i
                    class="fas fa-plus fa-sm text-white-50"></i> Add Event</a>
                      

        </div>
        <table id="dataTable" class="table table-bordered">
            <thead>
              <tr class="text-center" style="background:rgb(35, 35, 245)">
                <th scope="col" class="text-white">Name</th>
                <th scope="col" class="text-white">Day(TK)</th>
                <th scope="col" class="text-white">Night(TK)</th>
                <th scope="col" class="text-white">Fullday(TK)</th>
                <th scope="col" class="text-white">Photo</th>
                <th scope="col" class="text-white">Status</th>

                <th class="text-white" scope="col">Action</th>

              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $halls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="text-center">
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->dPrice); ?></td>
                <td><?php echo e($item->nPrice); ?></td>
                <td><?php echo e($item->fPrice); ?></td>
                <td>
                  <?php if(!empty($item->image)): ?>
                <img src="<?php echo e(asset('assets/img/hall/'.$item->image)); ?>" style="width:250px;" alt="">
                <?php endif; ?>
                </td>
                <td class="center"><?php if($item->status==1): ?> Active <?php else: ?> Inactive <?php endif; ?></td>
                <td>
                    <a href="<?php echo e(route('editHall',$item->id)); ?>"  class="btn btn-primary btn-sm mr-1 edit"><span class="fa fa-edit"></span></a>
                                      
                    <a href="<?php echo e(route('deleteHall',$item->id)); ?>"  class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </tbody>
          </table>


    </div>    


    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/hall/show.blade.php ENDPATH**/ ?>