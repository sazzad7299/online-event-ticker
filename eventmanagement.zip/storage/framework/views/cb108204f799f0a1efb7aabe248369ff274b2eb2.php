<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Request for New Reservation</title>
</head>
<body>
    <h1>Hi Admin!</h1>
    <h2>My Name is <strong><?php echo e($name); ?></strong></h2>
    <p>I need you <strong><?php echo e($hall); ?></strong> for <strong><?php echo e($ocation); ?></strong> </p>
    <br> 
    <br>
    <p>Hall/Center : <strong><?php echo e($hall); ?></strong></p>
    <p>Ocation: <strong><?php echo e($ocation); ?></strong></p>
    <p>Date: <strong><?php echo e($date); ?></strong></p>
    <p>Time : <strong><?php echo e($time); ?></strong></p>
    <p>Person's: <strong><?php echo e($person); ?></strong></p>
    <p>Budget: <strong><?php echo e($budget); ?></strong></p>

    <h1> Contact Me:</h1>
    <p>Eamil: <?php echo e($email); ?></p>
    <p>Phone: <?php echo e($contact); ?></p>

    
    
</body>
</html><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/emails/reserve.blade.php ENDPATH**/ ?>