
<?php $__env->startSection('main_content'); ?>
    <div class="container-fluid">
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add Hall/Center</h1>
        <a href="<?php echo e(route('viewHall')); ?>"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" ><em class=" text-white-50"></em>All Hall/Center</a>                  
    </div>
        <?php if(Session::has('flash_message_error')): ?>
        <div class="alert alert-error alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_error'); ?></strong>
        </div>
        <?php endif; ?>   
        <?php if(Session::has('flash_message_success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_success'); ?></strong>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('addHall')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name" id="name"  placeholder="Enter Hall Name" required value="<?php echo e(old('title')); ?>">

            </div>

            <div class="form-group">
              <label for="exampleInputPassword1">Description</label>
              <textarea id="summary" name="desc" rows="8" cols="80" class="form-control" value="<?php echo e(old('detail')); ?>" required> </textarea>
            </div> 
            <div class="form-group">
                <label for="fname" class="control-label">Day Price:</label>
                 <input type="number" class="form-control" name="dPrice" min="0" required>
            </div> 
            <div class="form-group">
                <label for="fname" class="control-label">Night Price:</label>
                 <input type="number" class="form-control" name="nPrice" min="0" required >
            </div>  
            <div class="form-group">
                <label for="fname" class="control-label">Fullday Price:</label>
                 <input type="number" class="form-control" name="fPrice"  min="0" required>
            </div>      
          
            <div class="form-group">
              <label for="image">Hall/Center Image</label>
              <input type="file" class="form-control" name="image" id="image" required >
            </div>

            <div class="form-group">
                <label for="fname" class="control-label col-form-label">Enable:</label>
                <input class="mt-2" type="checkbox"  name="status" id="status" value="1">
            </div>
            <button type="submit" class="btn btn-primary">Add Hallroom</button>
          </form>
    </div>
<?php $__env->stopSection(); ?>


<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>

<script type="text/javascript">
function test()
{
  alert('tesing');
}
  $(document).ready(function() {
    $('#summary').summernote();
  });
  </script>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/hall/create.blade.php ENDPATH**/ ?>