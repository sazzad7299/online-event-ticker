<style>
    .userMenu{
        position: fixed;
    }
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      width: 200px;
      background-color: #f1f1f1;
    }
    
    li a {
      display: block;
      color: #000;
      padding: 8px 16px;
      text-decoration: none;
    }
    
    li a.active {
      background-color: #04AA6D;
      color: white;
    }
    
    li a:hover:not(.active) {
      background-color: #555;
      color: white;
    }
    </style>

<ul class="userMenu">
    <li><a class="active" href="#home">Dashboard</a></li>
    <li><a href="#news">Booking</a></li>
    <li><a href="#contact">Ongoing Event</a></li>
    <li><a href="#about">Download</a></li>
  </ul><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/sidebar.blade.php ENDPATH**/ ?>