

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Coundown Section Start -->
    <section class="countdown-timer section-padding">
        <div class="container">
          <div class="row text-center">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="heading-count">
                <h2 class="wow fadeInDown" data-wow-delay="0.2s">Event Will Start In</h2>
              </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="row time-countdown justify-content-center wow fadeInUp" data-wow-delay="0.2s">
                <div id="clock" class="time-count"></div>
              </div>
              <a href="pricing.html" class="btn btn-common wow fadeInUp" data-wow-delay="0.3s">Add to My Calender</a>
            </div>
          </div>
        </div>
      </section>
      <!-- Coundown Section End -->

  
      <!-- About Section Start -->
      <section id="about" class="section-padding">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="section-title-header text-center">
                <h1 class="section-title wow fadeInUp" data-wow-delay="0.2s">Our Latest Events</h1>
                <p class="wow fadeInDown" data-wow-delay="0.2s">Global Grand Event on Digital Design</p>
              </div>
            </div>
          </div>
          <div class="row">
            <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-md-6 col-lg-4">
              <div class="about-item">
                <img class="img-fluid" src="<?php echo e(asset('images/event/'.$item->image)); ?>" alt="">
                <div class="about-text">
                  <h3><a href="#"><?php echo e($item->title); ?></a></h3>
                  <h5>  <?php echo e($item->price); ?>৳</h5>
                  <p><?php echo Str::limit($item->detail, 200); ?></p> <br>
                  <?php if($item->seat ==0): ?>
                  <button type="button" class="btn btn-common btn-rm" disabled>Not Available</button>
                  <a class="btn btn-common btn-rm" href="<?php echo e(url('event/'.$item->id)); ?>">View Details</a>
                  <?php else: ?>
                  <a class="btn btn-common btn-rm" href="<?php echo e(url('cart/'.$item->id)); ?>">Book Now</a>
                  <a class="btn btn-common btn-rm" href="<?php echo e(url('event/'.$item->id)); ?>">View Details</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
      </section>
      <!-- About Section End -->
  
      <!-- Schedule Section Start -->
      <section id="schedules" class="schedule section-padding">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="section-title-header text-center">
                <h1 class="section-title wow fadeInUp" data-wow-delay="0.2s">Event Schedules</h1>
                <p class="wow fadeInDown" data-wow-delay="0.2s">Hi, find your event which is match with your schedules <br> Enjoy your event</p>
              </div>
            </div>
          </div>
          <div class="schedule-area row wow fadeInDown" data-wow-delay="0.3s">
            <div class="schedule-tab-title col-md-3 col-lg-3 col-xs-12">
              <div class="table-responsive">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item">
                    <a class="nav-link <?php if($key==0): ?>active <?php endif; ?> " id="<?php echo e($item->id); ?>-tab" data-toggle="tab" href="#<?php echo e($item->id); ?>" role="tab" aria-controls="monday" aria-expanded="true">
                      <div class="item-text">
                        <h4><?php echo date('D',strtotime($item->start_date));?></h4>
                        <h5><?php echo date('d F',strtotime($item->start_date));?></h5>
                      </div>
                    </a>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
            <div class="schedule-tab-content col-md-9 col-lg-9 col-xs-12 clearfix">
              <div class="tab-content" id="myTabContent">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade show <?php if($key==0): ?>active <?php endif; ?>" id="<?php echo e($item->id); ?>" role="tabpanel" aria-labelledby="<?php echo e($item->id); ?>-tab">
                  <div id="accordion">
                    <div class="card">
                      <div id="headingOne">
                        <div class="collapsed card-header" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                          <div class="images-box">
                            <img class="img-fluid" src="<?php echo e(asset('images/event/'.$item->image)); ?>" alt="">
                          </div>                     
                          <h4><?php echo e($item->title); ?></h4>
                          <h5 class="name"><?php echo e($item->venue); ?></h5>
                        </div>
                      </div>
                      <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                        <div class="card-body">
                          <img class="img-fluid" src="<?php echo e(asset('images/event/'.$item->image)); ?>" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Schedule Section End -->

  
      <!-- Blog Section Start -->
      
      <!-- Blog Section End -->
  
      <!-- Subscribe Area Start -->
      
      <!-- Subscribe Area End -->
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/index.blade.php ENDPATH**/ ?>