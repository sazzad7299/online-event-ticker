


<?php $__env->startSection('main_content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="content">
        <a href="<?php echo e(route('admin.orders')); ?>" class="btn btn-primary">Back</a>
        <button style="" class="btn btn-danger" onclick="printDiv('printMe')"> <em class="fas fa-print" ></em></button>
          <div class="card" id="printMe">
            <div class="card-body" >
              <h4 class="card-title">Booking #</h4>
              
              <div class="row">
                <div class="col-md-6">
                    <p class="card-description">
                        <h4>User Details</h4>
                      </p>
                  <address>
                    <p class="fw-bold">Name: <?php echo e($user->name); ?></p>
                    <p>
                      Email:<?php echo e($user->email); ?>

                    </p>
                    <p>
                        Phone: <?php echo e($user->phone); ?>

                    </p>
                  </address>
                </div>
                <div class="col-md-6">
                    <p class="card-description">
                        <h4>Payment Details</h4>
                      </p>
                  <address >
                    <p>Payment Method: <strong><?php echo e($order->payment_method); ?></strong></p>
                    <p>Transection Number: <strong><?php echo e($order->transaction_number); ?></strong></p>
                    <p>Transection Id: <strong><?php echo e($order->transaction_id); ?></strong></p>
                    <p>Amount: <strong><?php echo e($order->grand_total); ?>৳</strong></p>
                    <p>Payment Status: <strong><?php echo e($order->status); ?></strong></p>
                  </address>
                </div>
              </div>
            </div>
            <div class="card-body">
              <h4 class="card-title">Event</h4>
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                      
                      <tr>
                          <th>
                            Name
                          </th>
                          <th>
                            Ticket
                          </th>
                          <th>
                            Amount
                          </th>
                        </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->event_name); ?></td>
                        <td><?php echo e($order->qty); ?></td>
                        <td><?php echo e($order->price); ?>৳</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div> 
            </div>
          </div>
      </div>
  </div>
  <script>
    function printDiv(printMe){
      var printContents = document.getElementById(printMe).innerHTML;
      var originalContents = document.body.innerHTML;
  
      document.body.innerHTML = printContents;
  
      window.print();
  
      document.body.innerHTML = originalContents;
  
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/orders/details.blade.php ENDPATH**/ ?>