
<?php $__env->startSection('content'); ?>
<div class="dashboard " style="background:black;padding-top:70px">
</div>
<div class="container">
    <div class="row " >
        <div class="col-md-12">
            <h5 class="text-center pb-5">All Categories</h5>
            <div class="row mb-5"> 
                <?php if(count($categories)>0): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="card">
                          <a href="<?php echo e(route('single_cat_page',['id'=>$category->id])); ?>"><img src="<?php echo e(asset('images/category/'.$category->photo)); ?>" 
                            class="card-img-top" alt="<?php echo e($category->title); ?>" height="250px" /></a>
                          <div class="card-body">
                            <h5 class="card-title"><a href="<?php echo e(route('single_cat_page',['id'=>$category->id])); ?>"><?php echo e($category->title); ?></a></h5>
                          </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p class="alert alert-danger">No Category Found</p>
                <?php endif; ?>
            </div>
            <!-- Pagination -->
            <?php echo e($categories->links()); ?>

        </div>
        <!-- Right SIdebar -->
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/frontend/categorie_show.blade.php ENDPATH**/ ?>