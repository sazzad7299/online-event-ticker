


<?php $__env->startSection('main_content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">User(All)</h4>
        <p class="card-description">
          
        </p>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead> 
                <tr>
                    <th>
                        #Id
                    </th>
                    <th>
                        Name
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        Phone
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                    <?php echo e($user->id); ?>

                    </td>
                    <td>
                    <?php echo e($user->name); ?>

                    </td>
                    <td>
                    <?php echo e($user->email); ?>

                    </td>
                    <td>
                    <?php echo e($user->phone); ?>

                    </td>
                    <td>
                    <a href="<?php echo e(url('admin/users/edit/'.$user->id)); ?>" ><em class="fas fa-edit" style="padding:5px; color: rgb(65, 63, 226);background:rgb(255, 195, 56)"></em></a>
                    <a href="<?php echo e(url('admin/users/delete/'.$user->id)); ?>" ><em class="fas fa-trash" style="padding:5px; color: red;background:orange"></em></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/users/user.blade.php ENDPATH**/ ?>