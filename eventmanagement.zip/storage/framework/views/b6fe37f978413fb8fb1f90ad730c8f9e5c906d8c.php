

<?php $__env->startSection('content'); ?>
<div class="dashboard " style="background:black;padding-top:70px">
</div>
<div class="dashboard1">
    <div class="right-sidebar">
        <ul>
            <li><a href="<?php echo e(route('home')); ?>" >Dashboard</a></li>
            <li><a href="#" class="active">Booking</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
          </ul>
    </div>
    <div class="navb">
      <ul>
        <li><a href="<?php echo e(route('home')); ?>" ><em class="lni lni-home"></em></a></li>
        <li><a href="#" class="active"><em class="lni lni-cart-full"></em></a></li>
        <li><a href="<?php echo e(route('profile')); ?>"><em class="lni lni-user"></em></a></li>
      </ul>
  </div>
    <div class="content">
        <div class="grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Your Booking Details</h4>
                <p class="card-description">
                  <code>You may download your ticket if admin verify your payment</code>
                </p>
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                        
                        <tr>
                            <th>
                              #id
                            </th>
                            <th>
                              Name
                            </th>
                            <th>
                              Ticket
                            </th>
                            <th>
                              Amount
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                              Action
                            </th>
                          </tr>
                        
                      
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="py-1">
                          <?php echo e($loop->iteration); ?>

                        </td>
                        <td>
                          <?php echo e($order->event_name); ?>

                        </td>
                        <td>
                          <?php echo e($order->qty); ?>

                        </td>
                        <td>
                          ৳<?php echo e($order->price); ?>

                        </td>
                        <td><?php echo e($order->pay_status); ?></td>
                        <td>
                          <a href="<?php echo e(url('home/booking/details/'.$order->id)); ?>"><em class="lni lni-eye"></em></a>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/users/booking.blade.php ENDPATH**/ ?>