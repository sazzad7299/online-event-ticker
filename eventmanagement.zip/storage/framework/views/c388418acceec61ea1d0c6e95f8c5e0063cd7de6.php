


<?php $__env->startSection('main_content'); ?>
 <!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="container-fluid">
         <form enctype="multipart/form-data" class="form-horizontal" method="post" action="<?php echo e(url('admin/edit-slider/'.$bannerDetails->id)); ?>" name="edit_banner" id="edit_banner" novalidate="novalidate"><?php echo e(csrf_field()); ?>

          <div class="row">
                <div class="col-md-8">
                    <div class="card">
                      <div class="card-body">
                        <?php if(Session::has('flash_message_error')): ?>
                        <div class="alert alert-error alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong><?php echo session('flash_message_error'); ?></strong>
                        </div>
                        <?php endif; ?>   
                        <?php if(Session::has('flash_message_success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button> 
                                    <strong><?php echo session('flash_message_success'); ?></strong>
                            </div>
                        <?php endif; ?>
                      </div>
                        <div class="card-body">
                            <div class="form-group row">
                                <label for="fname" class="col-sm-3 text-right control-label col-form-label">Banner Heading(h1):</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="title" value="<?php echo e($bannerDetails->title); ?>"  required="true">
                                </div>
                            </div>
                            
                            <div class="form-group row">
                                <label for="fname" class="col-sm-3 text-right control-label col-form-label">Banner Text(p)</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="text" id="text" value="<?php echo e($bannerDetails->text); ?>" required="true">
                                </div>
                            </div>
                            <div class="form-group row">
                              <input type="hidden" name="current_image" value="<?php echo e($bannerDetails->image); ?>">
                              <label class="col-sm-3 text-right control-label col-form-label">Banner Image</label>
                              <div class="col-sm-9">
                                <input name="image" id="image" type="file" size="19" >  
                              </div>
                            </div>
                            <div class="form-group row">
                              <label for="fname" class="col-sm-3 text-right control-label col-form-label">Banner Text Position</label>
                              <div class="col-sm-9">
                                  <select name="position" id="position" class="form-control">
                                      <option value="0"  <?php if($bannerDetails->position==0): ?> selected <?php endif; ?>>MIDDLE</option>
                                      <option value="1" <?php if($bannerDetails->position==1): ?> selected <?php endif; ?>>TOP-LEFT</option>
                                      <option value="2" <?php if($bannerDetails->position==2): ?> selected <?php endif; ?>>TOP-RIGHT</option>
                                      <option value="3" <?php if($bannerDetails->position==3): ?> selected <?php endif; ?>>BUTTOM-LEFT</option>
                                      <option value="4" <?php if($bannerDetails->position==4): ?> selected <?php endif; ?>>BUTTOM-RIGHT</option>
                                      
                                  </select>
                              </div>
                          </div>
                            
                            <div class="form-group row">
                                <label for="fname" class="col-sm-3 text-right control-label col-form-label">Enable:</label>
                                <div class="col-sm-9">
                                    <input class="mt-2" type="checkbox"  name="status" id="status" value="1" <?php if($bannerDetails->status=="1"): ?> checked <?php endif; ?> >
                                </div>
                            </div>
                            <div class="border-top">
                                <div class="card-body">
                                    <input type="submit" class="btn btn-primary" value="Update Banner">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>   
    </div>
</div>
<!-- /.container-fluid -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/slider/edit_slider.blade.php ENDPATH**/ ?>