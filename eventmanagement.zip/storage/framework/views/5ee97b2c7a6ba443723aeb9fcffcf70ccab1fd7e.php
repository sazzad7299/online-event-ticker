


<?php $__env->startSection('main_content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <a id="complete" class="card-title btn btn-primary m-2 text-white">Completed (<?php echo e($comorders->count()); ?>)</a><a id="pending"  class="card-title btn btn-danger m-2 text-white">Pending (<?php echo e($pendingorders->count()); ?>)</a>
        <p class="card-description">
            <?php if(Session::has('message')): ?>  
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('message'); ?></strong>
            </div>
        <?php endif; ?>
        </p>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead> 
                <tr>
                    <th>
                        #Id
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        Amount
                    </th>
                    <th>
                        Payment Method
                    </th>
                    <th>
                        Trans Num
                    </th>
                    <th>
                        Trans Id
                    </th>
                    <th>
                        Status
                    </th>
                    <th>View</th>
                </tr>
            </thead>
            <tbody class="complete">
            <?php $__currentLoopData = $comorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                    <?php echo e($order->id); ?>

                    </td>
                    <td>
                    <?php echo e($order->user_email); ?>

                    </td>
                    <td>
                        <?php echo e($order->grand_total); ?>

                    </td>
                    <td>
                    <?php echo e($order->payment_method); ?>

                    </td>
                    <td>
                    <?php echo e($order->transaction_number); ?>

                    </td>
                    <td>
                    <?php echo e($order->transaction_id); ?>

                    </td>
                    <td>
                    <span class="btn btn-primary"><?php echo e($order->status); ?></span>
                    </td>
                    <td><a href="<?php echo e(url('admin/orders/details/'.$order->id)); ?>" class="btn btn-warning"> <em class="fas fa-eye"></em></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tbody class="pending">
                <?php $__currentLoopData = $pendingorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                        <?php echo e($order->id); ?> 
                        </td>
                        <td>
                        <?php echo e($order->user_email); ?>

                        </td>
                        <td>
                            <?php echo e($order->grand_total); ?>

                        </td>
                        <td>
                        <?php echo e($order->payment_method); ?>

                        </td>
                        <td>
                        <?php echo e($order->transaction_number); ?>

                        </td>
                        <td>
                        <?php echo e($order->transaction_id); ?>

                        </td>
                        <td>
                            <span class="dropdown">
                                <button class="btn btn-primary dropdown-toggle btn-xs" type="button" data-toggle="dropdown"><?php echo e(ucfirst($order->status)); ?>

                                    <span class="caret"></span></button>
                                <ul class="dropdown-menu">
                                    <li class="nav-item"><a class="nav-link" href="orders/status/<?php echo e($order->id); ?>/complete">Completed</a></li>
                                </ul>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/orders/orders.blade.php ENDPATH**/ ?>