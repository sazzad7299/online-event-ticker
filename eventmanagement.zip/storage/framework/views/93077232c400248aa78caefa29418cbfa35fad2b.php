


<?php $__env->startSection('main_content'); ?>
 <!-- Begin Page Content -->
 <div class="container-fluid">

    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
              <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">AlL Sliders</h1>
                <a href="<?php echo e(route('addslider')); ?>"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" ><i
                        class="fas fa-plus fa-sm text-white-50"></i> Add Slider</a>
                          
    
            </div>
                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered">
                      <thead>
                        <tr class="text-center" style="background:rgb(35, 35, 245)">
                          <th scope="col" class="text-white">Banner ID</th>
                          <th scope="col" class="text-white">Title</th>
                          <th scope="col" class="text-white">Position</th>
          
                          <th scope="col" class="text-white">Image</th>
                          <th scope="col" class="text-white">Status</th>
          
                          <th class="text-white" scope="col">Action</th>
          
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="gradeX">
                          <td class="center"><?php echo e($banner->id); ?></td>
                          <td class="center"><?php echo e($banner->title); ?></td>
                          <td>
                            <?php if($banner->position==0): ?> Middle <?php endif; ?>
                            <?php if($banner->position==1): ?> TOP-LEFT <?php endif; ?>
                            <?php if($banner->position==2): ?> TOP-RIGHT <?php endif; ?>
                            <?php if($banner->position==3): ?> BUTTOM-LEFT <?php endif; ?>
                            <?php if($banner->position==4): ?> BUTTOM-RIGHT  <?php endif; ?>
                            
                          </td>
                          <td class="center">
                            <?php if(!empty($banner->image)): ?>
                            <img src="<?php echo e(asset('assets/img/slider/'.$banner->image)); ?>" style="width:250px;" alt="">
                            <?php endif; ?>
                          </td>
                          <td class="center"><?php if($banner->status==1): ?> Active <?php else: ?> Inactive <?php endif; ?></td>
                          <td class="center">
                            <a href="<?php echo e(route('editslider',$banner->id)); ?>" class="btn btn-primary btn-mini"><em class="far fa-edit"></em></a> 
                            <a  href="<?php echo e(route('deleteSlider',$banner->id)); ?>" class="btn btn-danger btn-mini"><em class="far fa-trash-alt"></em></a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
    
                    </table>
                </div>

            </div>
          </div>
    </div>
</div>
<!-- /.container-fluid -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/slider/view_slider.blade.php ENDPATH**/ ?>