
<?php $__env->startSection('main_content'); ?>
    <div class="container-fluid">
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">All Category</h1>
        <a href="<?php echo e(route('allCategory')); ?>"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" ><i
                class="  text-white-50"></i> AllCategory</a>
                  

    </div>
        <form action="<?php echo e(route('updateCategory',$category->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
              <label for="name">Title</label>
              <input type="text" class="form-control" name="title" id="name" aria-describedby="emailHelp" value="<?php echo e($category->title); ?>">
            </div>

            <div class="form-group">
              <label for="exampleInputPassword1">Description</label>
              <textarea name="summary" id="summary" rows="10" cols="80" class="form-control"><?php echo e($category->summary); ?></textarea>
            </div>
            

            <div class="form-group">
              <label for="exampleInputPassword1">Parent Category (optional)</label>
              <select class="form-control" name="parent_id">
                <option value="">Please select a Parent category</option>
                <?php $__currentLoopData = $parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($parent->id); ?>" <?php echo e($parent->id==$parent->id?'selected':''); ?>>
                    <?php echo e($parent->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

            </div>
            <div class="form-group">
                <label for="status" class="col-form-label">Status <span class="text-danger">*</span></label>
                <select name="status" class="form-control">
                    <option value="active"><?php echo e($category->status); ?></option>

                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

            <div>
              <img height="150" width="150" src="<?php echo e(asset('images/category/'.$category->photo)); ?>" alt="">
            </div>
            <div class="form-group">
              <label for="image">Category Image (optional)</label>
              <input type="file" class="form-control" name="image" id="image" >
            </div>


            <button type="submit" class="btn btn-primary">Update Category</button>
          </form>
    </div>
<?php $__env->stopSection(); ?>


<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>

<script type="text/javascript">
function test()
{
  alert('tesing');
}
  $(document).ready(function() {
    $('#summary').summernote();
  });
  </script>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>