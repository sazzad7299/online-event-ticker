
<?php $__env->startSection('content'); ?>
<div class="dashboard " style="background:black;padding-top:70px">
</div>

<div class="container">

    <div class="row">
        <?php if(count($event)>0): ?>
        <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-md-6 col-lg-4">
          <div class="about-item">
            <img class="img-fluid" src="<?php echo e(asset('images/event/'.$item->image)); ?>" alt="">
            <div class="about-text">
              <h3><a href="#"><?php echo e($item->title); ?></a></h3>
              <h5>  <?php echo e($item->price); ?>৳</h5>
              <p><?php echo Str::limit($item->detail, 200); ?></p> <br>
              <?php if($item->seat ==0): ?>
              <button type="button" class="btn btn-common btn-rm" disabled>Not Available</button>
              <?php else: ?>
              <a class="btn btn-common btn-rm" href="<?php echo e(url('cart/'.$item->id)); ?>">Book Now</a>
              <a class="btn btn-common btn-rm" href="<?php echo e(url('event/'.$item->id)); ?>">View Details</a>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <p class="alert alert-danger">No Event Found</p>
        <?php endif; ?>

        <div>
             <!-- Pagination -->
             <?php echo e($event->links()); ?>

        </div>
      </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Event Management\eventmanagement\resources\views/frontend/single_cat_event.blade.php ENDPATH**/ ?>